
$("button").click(function(){
		$(this).toggleClass("CelineRedCSS");
});